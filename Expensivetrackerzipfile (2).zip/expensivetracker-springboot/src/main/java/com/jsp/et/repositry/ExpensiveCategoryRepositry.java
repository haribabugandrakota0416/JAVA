package com.jsp.et.repositry;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.et.entity.ExpensiveCategery;

public interface ExpensiveCategoryRepositry extends JpaRepository<ExpensiveCategery, Integer> {
	
	Optional<ExpensiveCategery> findByCategery(String category);

}
