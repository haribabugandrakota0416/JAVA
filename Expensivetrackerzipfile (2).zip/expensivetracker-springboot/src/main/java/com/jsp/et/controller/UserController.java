package com.jsp.et.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Base64;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.jsp.et.dto.ExpensiveDTO;
import com.jsp.et.dto.ImageDTO;
import com.jsp.et.dto.TotalDTO;
import com.jsp.et.dto.UserDTO;
import com.jsp.et.entity.User;
import com.jsp.et.service.ExpensiveService;
import com.jsp.et.service.UserService;

@Controller
public class UserController {

	@Autowired
	private UserService userService;

	@Autowired
	private ExpensiveService expenseService;
	
	
	@PostMapping("/register")
	public String registration(@ModelAttribute UserDTO userDTO,Model m, RedirectAttributes attributes) {
		int id=userService.registration(userDTO);
		if(id!=0) {
			//to display login page
			//redirect request to login method
			//m.addAttribute("msg","Registration successfull...!!");
			attributes.addFlashAttribute("msg","Registration successfull...!!");
			return "redirect:/expense/login";
		}
		//display registration page
		//m.addAttribute("msg","enter valid details...!!");
		attributes.addFlashAttribute("msg", "Enter valid details...!!");
		return "redirect:/expense/registration";
	}

	@PostMapping("/loginoperation")
	public String login(@ModelAttribute UserDTO userDTO,RedirectAttributes attributes,HttpServletRequest request) {
		UserDTO dto=userService.login(userDTO); 
		if(dto!=null) {
			//to store user data in session object
			request.getSession().setAttribute("user", dto);
			return "redirect:/expense/home";
		}
		attributes.addFlashAttribute("msg","Enter valid details...!!");
		return "redirect:/expense/login";
	}

	@PostMapping("/addExpense/{id}")
	public String addExpense(@ModelAttribute ExpensiveDTO dto, @PathVariable("id") int userid
			,RedirectAttributes attributes) {
		int id= expenseService.addExpense(dto, userid);
		if(id>0) {
			//return ResponseEntity.status(HttpStatus.CREATED).body(id);
			
			//attributes.addFlashAttribute("listOfExpenses", expenses);
			return "redirect:/viewExpense/"+userid;
		}
		attributes.addFlashAttribute("error", "please enter valid details");
		return "redirect:/expense/addexpenses";
	}

	@GetMapping("/viewExpense/{id}")
	public String  viewExpense(@PathVariable("id") int userid,RedirectAttributes attributes) {
		List<ExpensiveDTO> expenses=expenseService.viewExpense(userid);
		if(!expenses.isEmpty()) {
			attributes.addFlashAttribute("listOfExpenses", expenses);
			return "redirect:/expense/viewexpensess";
		}
		return "redirect:/expense/home";
	}

	@RequestMapping("/updateexpense/{eid}")
	public String updateExpense(@ModelAttribute ExpensiveDTO dto, @PathVariable("eid") int expensiveid,HttpServletRequest request)
	{
		ExpensiveDTO expense= expenseService.updateExpense(dto, expensiveid);
		if(expense!=null) {
			UserDTO userdto=(UserDTO)request.getSession().getAttribute("user");
			return "redirect:/viewExpense/"+userdto.getUserid();
		}
		return "redirect:/expense/home";
	}

	@GetMapping("/deletExpense/{eid}")
	public String deletExpense(@PathVariable("eid") int expensiveid,RedirectAttributes attributes,HttpServletRequest request) {
		int id= expenseService.deletExpense(expensiveid);
		if(id!=0)
		{
			UserDTO userdto=(UserDTO)request.getSession().getAttribute("user");
			
			return "redirect:/viewExpense/"+userdto.getUserid();
		}
		return "redirect:/expense/viewexpensess";
		
	}
	
	@GetMapping("/expense/{eid}")
	public ResponseEntity<ExpensiveDTO> findByExpenseId(@PathVariable("eid") int expensiveid){
		ExpensiveDTO dto=expenseService.findByExpensiveid(expensiveid);
		if(dto!=null)
		{
			return ResponseEntity.status(HttpStatus.OK).body(dto);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	@GetMapping("/filter/{uid}")
	public String  filterBasedOnDateCategeryAmount(@ModelAttribute ExpensiveDTO dto, @PathVariable("uid") int userid
			,RedirectAttributes attributes)
	{
		if(!dto.getRange().equalsIgnoreCase("0"))
		{
		List<ExpensiveDTO> filterBasedOnAmount = expenseService.filterBasedOnAmount(userid, dto.getRange());
		attributes.addFlashAttribute("listOfExpenses", filterBasedOnAmount);
		return "redirect:/expense/viewexpensess";
		}
		else if(dto.getDate()!="")
		{
			List<ExpensiveDTO> filterBasedOnDate = expenseService.filterBasedOnDate(dto, userid);
			attributes.addFlashAttribute("listOfExpenses", filterBasedOnDate);
			return "redirect:/expense/viewexpensess";
			
		}
		else if(dto.getCategery()!="")
		{
	        List<ExpensiveDTO> filterBasedOnCategery = expenseService.filterBasedOnCategery(dto, userid);
			attributes.addFlashAttribute("listOfExpenses", filterBasedOnCategery);
			return "redirect:/expense/viewexpensess";
		}
		return "redirect:/expense/home";
		
	}
	
	@RequestMapping("/filterByDate/{uid}")
	public String filterBasedOnDate(@ModelAttribute ExpensiveDTO dto, @PathVariable("uid") int userid,RedirectAttributes attributes)
	{
		if(dto.getDate()!="")
		{
			List<ExpensiveDTO> filterBasedOnDate = expenseService.filterBasedOnDate(dto, userid);
			attributes.addFlashAttribute("listOfExpenses", filterBasedOnDate);
			return "redirect:/expense/viewexpensess";
		}
		return "redirect:/expense/home";
	}
	
	
	@GetMapping("/filterByAmount/{uid}/{amounts}")
	public ResponseEntity<List<ExpensiveDTO>> filterBasedOnAmount(@PathVariable("uid") int userid,@PathVariable("amounts")String amount,HttpServletRequest request)
	{
		UserDTO userdto=(UserDTO)request.getSession().getAttribute("user");
		List<ExpensiveDTO> expenses=expenseService.filterBasedOnAmount(userdto.getUserid(), amount);
		if(expenses!=null) {
			return ResponseEntity.status(HttpStatus.OK).body(expenses);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	@GetMapping("/filterByCategery/{uid}")
	public String filterBasedOnCategery(@ModelAttribute ExpensiveDTO dto, @PathVariable("uid") int userid,RedirectAttributes attributes)
	{
		
		if(dto.getCategery()!="") {
			 List<ExpensiveDTO> filterBasedOnCategery = expenseService.filterBasedOnCategery(dto, userid);
				attributes.addFlashAttribute("listOfExpenses", filterBasedOnCategery);
				return "redirect:/expense/viewexpensess";
		}
		return "redirect:/expense/home";
	}
	
	@GetMapping("/filterByCategeryAmount/{uid}/{amounts}")
	public ResponseEntity<List<ExpensiveDTO>> filterBasedOnCategeryAmount(@RequestBody ExpensiveDTO dto, @PathVariable("uid") int userid,@PathVariable("amounts")String amount)
	{
		List<ExpensiveDTO> expenses=expenseService.filterBasedOnCategeryAmount(dto, userid, amount);
		if(expenses!=null) {
			return ResponseEntity.status(HttpStatus.OK).body(expenses);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
	}	
	
	@GetMapping("/totalExpensesByStartDateEndDate/{uid}")
	public String getTotalExpense(@ModelAttribute TotalDTO dto,@PathVariable("uid") int userid,Model m)
	{
		List<ExpensiveDTO> filterExpensesBasedOnDate = expenseService.filterExpensesBasedOnDate(LocalDate.parse(dto.getStart()), LocalDate.parse(dto.getEnd()), userid);
		m.addAttribute("listOfExpenses", filterExpensesBasedOnDate);
		m.addAttribute("total",filterExpensesBasedOnDate.stream().mapToDouble(t->t.getAmount()).sum());
		return "viewexpenses";
	}
	
	@GetMapping("/findbyuserid/{uid}")
	public ResponseEntity<UserDTO> findByUserId(@PathVariable("uid") int userid) {
		UserDTO user=userService.findByUserId(userid);
		if(user!=null) {
			return ResponseEntity.status(HttpStatus.OK).body(user);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
		
	}
	
	@DeleteMapping("/deletuser/{id}")
	public ResponseEntity<Integer> deletUser(@PathVariable("id") int id){
		int status=userService.deletUserProfile(id);
		if(status!=0)
		{
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body(status);
		}
		return ResponseEntity.status(HttpStatus.NOT_FOUND).body(0);
	}
	
	@PutMapping("/updateprofile/{uid}")
	public ResponseEntity<UserDTO>  updateUserProfile(@RequestBody UserDTO dto,@PathVariable("uid")int userid) {
		
		UserDTO updated=userService.updateUserProfile(userid, dto);
		if(updated!=null)
		{
			return ResponseEntity.status(HttpStatus.OK).body(updated);
		}
		return ResponseEntity.status(HttpStatus.OK).body(null);
	}	
	
	@PostMapping("/updateuser/{id}")
	public String updateUser(@PathVariable("id") int id, @ModelAttribute UserDTO dto,
							 @RequestParam("imageFile") MultipartFile file, HttpServletRequest request) {
		try {
			/**
			 * retrieve UserDTO object from session object, store at the time of Login
			 */
			UserDTO fromSession= (UserDTO)request.getSession().getAttribute("user");
			//if user already have uploaded profile photo then update the photo
			if(fromSession.getImage() != null) {
				//updation logic
				fromSession.getImage().setData(file.getBytes());
				dto.setImage(fromSession.getImage());

				//store same image in session object
				request.getSession().setAttribute("image", 
						Base64.getMimeEncoder().encodeToString(dto.getImage().getData()));
			}
			else {
			//if user uploading profile photo first time 
				ImageDTO imageDto = new ImageDTO();
				imageDto.setData(file.getBytes());
				dto.setImage(imageDto);
			}

			userService.updateUserProfile(id, dto);
			return "redirect:/expense/home";

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "redirect:/expense/home";
	}
}
