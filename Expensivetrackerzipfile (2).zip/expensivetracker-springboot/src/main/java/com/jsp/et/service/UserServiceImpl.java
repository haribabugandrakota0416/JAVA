package com.jsp.et.service;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.jsp.et.dto.UserDTO;
import com.jsp.et.entity.User;
import com.jsp.et.repositry.UserRepostry;

//business logic
@Service
public class UserServiceImpl implements UserService {
	@Autowired
	private UserRepostry repositry;

	@Override
	public int registration(UserDTO dto) {
		// create an object of entity class

		// repository can't access the dto's data transfer object
		// DTO stands for data transfer object from controller to service
		User userdb = new User();
		/*
		 * Basic way userdb.setFullName(dto.getFullName);
		 * userdb.setUserName(dto.getUserName);
		 */
		BeanUtils.copyProperties(dto, userdb);
		if(dto.getPassword().equals(dto.getRepassword()))
		{

		return repositry.save(userdb).getUserid();
		}
		return 0;
	}

	@Override
	public UserDTO login(UserDTO dto) {
		Optional<User> findByUserNameAndPassword = repositry.findByUserNameAndPassword(dto.getUserName(),
				dto.getPassword());
		UserDTO verifiedUser = new UserDTO();
		if (findByUserNameAndPassword.isPresent()) {
			User userdb = findByUserNameAndPassword.get();
			BeanUtils.copyProperties(userdb, verifiedUser);
			return verifiedUser;
		}
		return null;
	}

	@Override
	public UserDTO findByUserId(int userid) {
		User user = repositry.findById(userid).get();
		UserDTO dto=new UserDTO();
		BeanUtils.copyProperties(user,dto);
		return dto;
	}

	@Override
	public UserDTO updateUserProfile(int userid, UserDTO dto) {
		User user=new User();
		user.setFullName(dto.getFullName());
		user.setUserName(dto.getUserName());
		user.setMobile(dto.getMobile());
		user.setPassword(dto.getPassword());
		UserDTO updated=new UserDTO();
		BeanUtils.copyProperties(repositry.save(user),updated);
		
		return updated;
	}

	@Override
	public int deletUserProfile(int userid) {
		Optional<User> user= repositry.findById(userid);
		if(user.isPresent())
		{
			repositry.delete(user.get());
			return 1;
		}
		return 0;
	}
}
