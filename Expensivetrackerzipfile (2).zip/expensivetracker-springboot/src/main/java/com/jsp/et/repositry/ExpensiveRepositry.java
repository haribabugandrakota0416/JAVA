package com.jsp.et.repositry;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.jsp.et.entity.Expensive;
import com.jsp.et.entity.User;

public interface ExpensiveRepositry extends JpaRepository<Expensive,Integer> {

	List<Expensive> findByUser(User user);
}
