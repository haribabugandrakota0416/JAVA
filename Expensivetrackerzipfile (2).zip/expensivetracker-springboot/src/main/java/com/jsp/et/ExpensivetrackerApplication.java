package com.jsp.et;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.jsp.et.controller.UserController;
import com.jsp.et.entity.ExpensiveCategery;
import com.jsp.et.repositry.ExpensiveCategoryRepositry;

@SpringBootApplication
public class ExpensivetrackerApplication implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(ExpensivetrackerApplication.class, args);
	}

	// @Autowired
	// private ExpensiveCategoryRepositry repositry;

	@Override
	public void run(String... args) throws Exception {
//		List<ExpensiveCategery> categories = Arrays.asList(new ExpensiveCategery("utilities"),
//				new ExpensiveCategery("Transportation"), new ExpensiveCategery("Groceries"),
//				new ExpensiveCategery("Dining out"), new ExpensiveCategery("HealthCare"),
//				new ExpensiveCategery("Entertainment"), new ExpensiveCategery("Education"),
//				new ExpensiveCategery("Personal Care"), new ExpensiveCategery("Clothin"),
//				new ExpensiveCategery("Home Maintaince"), new ExpensiveCategery("Gifts and Donations"),
//				new ExpensiveCategery("Savings & Investments"), new ExpensiveCategery("Tax"),
//				new ExpensiveCategery("others"));
//		// to store all list elements in the database
//
//		repositry.saveAll(categories);

	}

}
